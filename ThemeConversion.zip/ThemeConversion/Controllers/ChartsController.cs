﻿using Microsoft.AspNetCore.Mvc;

namespace ThemeConversion.Controllers
{
    public class ChartsController : Controller
    {
        public IActionResult Chartjs()
        {
            return View();
        }

        public IActionResult ApexCharts()
        {
            return View();
        }

        public IActionResult ECharts()
        {
            return View();
        }
    }
}
