﻿using Microsoft.AspNetCore.Mvc;

namespace ThemeConversion.Controllers
{
    public class FormsController : Controller
    {
        public IActionResult Form_Elements()
        {
            return View();
        }

        public IActionResult Form_Layouts()
        {
            return View();
        }

        public IActionResult Form_Editors()
        {
            return View();
        }

        public IActionResult Form_Validation()
        {
            return View();
        }
    }
}
