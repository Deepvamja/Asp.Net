﻿using Microsoft.AspNetCore.Mvc;

namespace ThemeConversion.Controllers
{
    public class TablesController : Controller
    {
        public IActionResult General_Tables()
        {
            return View();
        }

        public IActionResult Data_Tables()
        {
            return View();
        }
    }
}
