﻿using Microsoft.AspNetCore.Mvc;

namespace ThemeConversion.Controllers
{
    public class IconsController : Controller
    {
        public IActionResult Bootstrap_Icons()
        {
            return View();
        }

        public IActionResult Remix_Icons()
        {
            return View();
        }

        public IActionResult Boxicons()
        {
            return View();
        }
    }
}
